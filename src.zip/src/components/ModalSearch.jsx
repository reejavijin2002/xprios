import React from 'react'

const ModalSearch = () => {
  return (
    <div></div>
  )
}

export default ModalSearch
