
import React from 'react'

const SurveyModal = () => {
  return (
    <div>SurveyModal</div>
  )
}

export default SurveyModal