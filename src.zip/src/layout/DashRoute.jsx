import React from 'react'

const DashRoute = () => {
  return (
    <></>
  )
}

export default DashRoute