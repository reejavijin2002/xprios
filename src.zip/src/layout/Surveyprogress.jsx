import React from 'react'

const Surveyprogress = () => {
  return (
    <div>Surveyprogress</div>
  )
}

export default Surveyprogress